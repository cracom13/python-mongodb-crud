from pydantic import BaseModel
from typing import Optional

# Modelo para recibir datos (no incluye el ID porque Mongo lo genera)
class UserIn(BaseModel):
    name: str
    email: str
    password: str

# Modelo para devolver datos (incluye el ID convertido a str)
class User(UserIn):
    id: Optional[str]

class UserUpdate(BaseModel):
    name: Optional[str]
    email: Optional[str]
    password: Optional[str]
    
