# FastAPI Mongodb REST API

### resources
* https://fastapi.tiangolo.com/tutorial/response-model/