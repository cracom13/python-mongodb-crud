from fastapi import APIRouter, HTTPException
import httpx

currency = APIRouter()

EXTERNAL_API_URL = "http://api.exchangeratesapi.io/v1/latest"
API_KEY = "5fa1a747ec054eb0a1ffc6e3370e6c23"  # Asegúrate de usar tu propia clave válida

@currency.get("/convert", tags=["currency"])
async def convert_currency(from_currency: str, to_currency: str, amount: float = 1.0):
    params = {
        "access_key": API_KEY,
        "symbols": f"{from_currency.upper()},{to_currency.upper()}"
    }

    async with httpx.AsyncClient() as client:
        response = await client.get(EXTERNAL_API_URL, params=params)

    if response.status_code != 200:
        raise HTTPException(status_code=500, detail="Error al consultar el servicio externo")

    data = response.json()
    print(data)  # para depurar

    rates = data.get("rates")
    if not data.get("success", True) or from_currency.upper() not in rates or to_currency.upper() not in rates:
        raise HTTPException(status_code=400, detail="Códigos de moneda inválidos o no disponibles")

    # Convertir desde 'from' a 'to' usando EUR como base común
    rate_from = rates[from_currency.upper()]
    rate_to = rates[to_currency.upper()]
    rate = rate_to / rate_from
    converted = amount * rate

    return {
        "from": from_currency.upper(),
        "to": to_currency.upper(),
        "amount": amount,
        "converted": round(converted, 4),
        "rate": round(rate, 6)
    }
